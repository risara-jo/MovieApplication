package com.example.MovieApplication.Entity;

public enum BookingStatus {
    CONFIRMED,
    CANCELLED,
    PENDING
}
